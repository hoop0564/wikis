local skynet = require "skynet"
local socket = require "skynet.socket"

local function accept(clientfd, addr)
    skynet.newservice("slave", clientfd, addr)-- 传参给服务的时候，clientfd,addr 都会转为string
end

skynet.start(function ()
    if tonumber(skynet.getenv("usedb")) > 0 then
        skynet.uniqueservice("DB")
    end
    local listenfd = socket.listen("0.0.0.0", 8001) -- socket bind listen 
    socket.start(listenfd, accept) -- 将listenfd注册到epoll，收到连接会回调accept函数
end)
