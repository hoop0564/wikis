local skynet = require "skynet"

local CMD = {}
local db = {}

local res = {}

function CMD.set(key, val)
    db[key] = val
    if res[key] then
        res[key](true, val)
    end
end

function CMD.get(key) -- skynet.call
    if not db[key] then
        res[key] = skynet.response()
        return
    end
    return skynet.retpack(db[key])
end

skynet.start(function ()
    skynet.dispatch("lua", function (_,_, cmd, ...)
        CMD[cmd](...)
    end)
end)
