local skynet = require "skynet"
local socket = require "skynet.socket"

local clientfd, addr = ...
clientfd = tonumber(clientfd)

local cache = {}

local dbserv

local CMD = {}

local function sendto(arg)
    local ret = table.concat({"fd:", clientfd, arg}, " ")
    print(ret)
    socket.write(clientfd, ret.."\n")
end

function CMD.set(key, val)
    if not (key and val) then
        sendto("error[set]: need tow params")
        return
    end
    -- 0mq
    if tonumber(skynet.getenv("usedb")) > 0 then
        skynet.send(dbserv, "lua", "set", key, val)
    else
        cache[key] = val
    end
    sendto(("send back: set %s=%s"):format(key, val))
end

function CMD.get(key)
    if not key then
        sendto("error[get]: need one params")
        return
    end
    -- RPC
    if tonumber(skynet.getenv("usedb")) > 0 then
        local val = skynet.call(dbserv, "lua", "get", key)
        sendto("return ".. tostring(val))
    else
        local val = cache[key]
        sendto("return "..tostring(val))
    end
end

skynet.start(function ()
    print("recv a connection:", clientfd, addr)
    socket.start(clientfd)-- clientfd 注册到epoll
    if tonumber(skynet.getenv("usedb")) > 0 then
        dbserv = skynet.uniqueservice("DB")
    end
    skynet.fork(function ()
        while true do
            local data = socket.readline(clientfd)--从网络获取 以\n为分隔符的数据包
            if not data then
                socket.close(clientfd)
                return
            end
            local pms = {}
            for pm in data:gmatch("%w+") do
                pms[#pms+1] = pm
            end
            if not next(pms) then
                sendto("error[format], recv data")
                goto __continue__
            end
            local cmd = pms[1]
            if not CMD[cmd] then
                sendto("error: command not exist")
                goto __continue__
            end
            skynet.fork(CMD[cmd], select(2, table.unpack(pms)))
::__continue__::
        end
    end)
end)
